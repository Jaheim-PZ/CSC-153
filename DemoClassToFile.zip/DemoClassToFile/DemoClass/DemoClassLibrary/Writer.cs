﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DemoClassLibrary
{
    public static class Writer
    {
        
        public static string WritePeopleToFile(List<DemoClass> people)
        {
            StreamWriter output;

            try
            {
                output = File.CreateText("people.csv");
                
                foreach(DemoClass person in people)
                {
                    output.WriteLine($"{person.FirstName},{person.MiddleName},{person.LastName},{person.Age}");
                }

                output.Close();

                return "Saved";
            }
            catch (Exception ex)
            {
                string exceptionMessage = ex.Message;

                return exceptionMessage;
                

            }

        }
    }
}
