﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoClassLibrary
{
    public class PeopleInformation
    {
        

        public static List<DemoClass> LoadList()
        {

            List<DemoClass> people = new List<DemoClass>();

            DemoClass tom = new DemoClass("Thomas", "Bob", "Blake", 27);
            DemoClass bob = new DemoClass("Bob", "Thomas", "Blake", 27);

            people.Add(bob);
            people.Add(tom);

            return people;
        }       

    }
}
