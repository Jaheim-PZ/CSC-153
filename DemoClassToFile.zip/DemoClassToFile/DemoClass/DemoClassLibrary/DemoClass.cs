﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoClassLibrary
{
    public class DemoClass
    {
        /**
        * CLASSOVERVIEW ------------------------------------------------------
        *
        * All "Classes" can have up to four parts. The reason for the "up to"
        * will be made clear as the demo progresses. 
        *
        * The for parts are:
        * - Field(s) (think of these a variables for the class)
        * - Property(ies) (Way to access the fields)
        * - Constructor(s) (What is used to create the object from the class)
        * - Method(s)
        *
        * All of the above, working together helps make an object from a class.
        */

        /**
        * CLASSINFO #1 --------------------------------------------------------
        *
        * Fields are variables that live within a "Class". This is why they are
        * often refereed to a "Member Variables". These will store data that is
        * needed for the object. 
        *
        * Fields should only be accessed from within the Object itself. There is
        * no need for the program to access these Fields directly from outside the
        * object. So the "Access Modifier" should always be "private". Just like
        * variables, Fields need a Datatype. Then the Field name, This changes above
        * little because the Field uses the "private" access modifier. The Field
        * names should start with an "Underscore" "_". This is common practice to
        * make easier for programmers to recognize that a variable or Field is
        * private.
        */

        // CLASSEXAMPLE #1
        private string _firstName;
        private string _lastName;
        private int _age;

        /**
        * CLASSINFO #4 ------------------------------------------------------------
        *
        * Constructors at their core are methods that create an object from the class.
        * Just like methods they can have parameters that accept arguments. These type
        * of "Constructors are called "Parameterized Constructors". Unlike methods however
        * "Constructors" do not need as much information in their header. It needs an
        * Access Modifier (public), Name of the "Class", and an parameters.
        *
        * A "Class" does not need a "Constructor" defined. If a "Constructor" is not defined,
        * then there is a hidden "Default Constructor" that builds and object with no values
        * in the "Fields". Once a "Constructor" is declared then there is no longer access to
        * the "Default Constructor". It is always a good idea to create a "Default Constructor"
        * if the class has another "Constructor" defined. This is called "OverLoading".
        *
        * "OverLoading" is having a Constructor/Method with the same name but different parameters.
        * This is the Constructor/Method's Signature.
        */

        // CLASEXAMPLE #2 (Default Constructor)
        public DemoClass()
        {
            FirstName = "";
            MiddleName = "";
            LastName = "";
            Age = 0;
        }

        // CLASEXAMPLE #2 (Parameterized Constructor)
        public DemoClass(string firstName, string middleName, string lastName, int age)
        {
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Age = age;
        }

        /**
        * CLASSINFO #3 -----------------------------------------------------------
        *
        * Properties are also class members that allow code outside of the object 
        * to "get" or "set" values to the Fields. Properties themselves do not hold
        * any values. 
        *
        * There are two types of Properties. The first one is the normal property.
        * This property requires a "backing field" which is just the "Member Variable".
        * This type of property should be used if values need some kind of change before
        * is is stored or returned to the calling member.
        *
        * Next is the "Auto-Property". This type of property does NOT need above
        * backing field. It will create its own hidden field. This type can be used
        * if the value does not need to change at all before storing or returning. For
        * this demo one "Auto-Property" will be created with no new Field to match.
        *
        * Properties should almost alway have the Access Modifier of public since this
        * is how code outside the object will access the private fields.
        *
        * The property's datatype should always match it's backing field. It is always
        * a good idea to have the property's name match the backing field's name but in
        * Pascal form.
        *
        * Any property can become "read-only" by simply leaving off any "sets".
        */

        // CLASEXAMPLE #3 (Properties)
        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }

        // CLASEXAMPLE #3 (Auto-Property) 
        public string MiddleName { get; set; }

        /**
        * CLASSEXAMPLE #4 ---------------------------------------------------------
        *
        * Class methods are just like any methods that have been used so far. They
        * can even be OverLoaded. A Class can even have no methods at all.
    `   */

        public void AddToAge(int input)
        {
            _age += input;
        }

        public void AddToAge(string input)
        {
            int num;

            if (int.TryParse(input, out num))        
            {
                _age += num;
        
            }
            else
            {
                Console.WriteLine("Not a valid number");
            }
        }

        // Find INFO #2 in "Progrma.cs"
    }
}
