﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<DemoClass> people = new List<DemoClass>();

            people = PeopleInformation.LoadList();

            string message = Writer.WritePeopleToFile(people);

            Console.WriteLine(message);


            Console.ReadLine();

        }
    }
}
